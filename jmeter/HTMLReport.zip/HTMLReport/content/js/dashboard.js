/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.5474666666666667, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.5, 500, 1500, " /api/jobs/6a852af1-30be-49f0-81c8-1360feb54bd8"], "isController": false}, {"data": [0.5419161676646707, 500, 1500, "/api/runs?job_uid=c3e67e02-124f-4954-8420-31353a891bb5"], "isController": false}, {"data": [0.5, 500, 1500, "28fc074b-6a9b-4370-8a59-6432df9ea729 COMPLETED 830"], "isController": false}, {"data": [0.5, 500, 1500, " /api/jobs/f813acbb-2a01-4f5d-be7b-2acdd89e630c"], "isController": false}, {"data": [0.625, 500, 1500, " /api/jobs"], "isController": false}, {"data": [0.5, 500, 1500, "c3e67e02-124f-4954-8420-31353a891bb5 COMPLETED 830"], "isController": false}, {"data": [0.5, 500, 1500, " /api/jobs/0162c22c-07b9-4700-8f66-c342d913ec13"], "isController": false}, {"data": [0.5, 500, 1500, " /api/jobs/28fc074b-6a9b-4370-8a59-6432df9ea729"], "isController": false}, {"data": [0.5, 500, 1500, "90b87dc5-ae70-4dde-9f73-7a1933a554a8 COMPLETED 825"], "isController": false}, {"data": [0.5, 500, 1500, " /api/jobs/90b87dc5-ae70-4dde-9f73-7a1933a554a8"], "isController": false}, {"data": [0.5, 500, 1500, "6a852af1-30be-49f0-81c8-1360feb54bd8 COMPLETED 830"], "isController": false}, {"data": [0.5, 500, 1500, " /api/jobs/c3e67e02-124f-4954-8420-31353a891bb5"], "isController": false}, {"data": [0.5333333333333333, 500, 1500, "/api/runs?job_uid=e419fb87-02e7-4a81-800d-de4e99bd6b6e"], "isController": false}, {"data": [0.5, 500, 1500, " /api/jobs/5ab16381-a8c5-44da-b080-1bcba21b0876"], "isController": false}, {"data": [0.5271084337349398, 500, 1500, "/api/runs?job_uid=d7639850-2324-4c8a-9b87-b07658f6378a"], "isController": false}, {"data": [0.5568862275449101, 500, 1500, "/api/runs?job_uid=6a852af1-30be-49f0-81c8-1360feb54bd8"], "isController": false}, {"data": [1.0, 500, 1500, "5ab16381-a8c5-44da-b080-1bcba21b0876 COMPLETED 905"], "isController": false}, {"data": [0.5598802395209581, 500, 1500, "/api/runs?job_uid=28fc074b-6a9b-4370-8a59-6432df9ea729"], "isController": false}, {"data": [0.0, 500, 1500, "Transaction Controller"], "isController": true}, {"data": [0.5, 500, 1500, "0162c22c-07b9-4700-8f66-c342d913ec13 COMPLETED 825"], "isController": false}, {"data": [1.0, 500, 1500, " /api/formats/gpkg"], "isController": false}, {"data": [1.0, 500, 1500, "f813acbb-2a01-4f5d-be7b-2acdd89e630c COMPLETED 915"], "isController": false}, {"data": [0.595108695652174, 500, 1500, "/api/runs?job_uid=f813acbb-2a01-4f5d-be7b-2acdd89e630c"], "isController": false}, {"data": [1.0, 500, 1500, "e419fb87-02e7-4a81-800d-de4e99bd6b6e COMPLETED 820"], "isController": false}, {"data": [0.05, 500, 1500, " /api/docs"], "isController": false}, {"data": [0.5, 500, 1500, " /api/login/"], "isController": false}, {"data": [0.5301204819277109, 500, 1500, "/api/runs?job_uid=0162c22c-07b9-4700-8f66-c342d913ec13"], "isController": false}, {"data": [0.5, 500, 1500, "14bb4617-0f52-474d-b240-f10c8cfab768 COMPLETED 820"], "isController": false}, {"data": [0.5851648351648352, 500, 1500, "/api/runs?job_uid=5ab16381-a8c5-44da-b080-1bcba21b0876"], "isController": false}, {"data": [0.5150602409638554, 500, 1500, "/api/runs?job_uid=90b87dc5-ae70-4dde-9f73-7a1933a554a8"], "isController": false}, {"data": [0.5, 500, 1500, " /api/jobs/d7639850-2324-4c8a-9b87-b07658f6378a"], "isController": false}, {"data": [0.5, 500, 1500, " /api/jobs/e419fb87-02e7-4a81-800d-de4e99bd6b6e"], "isController": false}, {"data": [0.5121212121212121, 500, 1500, "/api/runs?job_uid=14bb4617-0f52-474d-b240-f10c8cfab768"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.7666666666666667, 500, 1500, " /api/formats"], "isController": false}, {"data": [0.5, 500, 1500, " /api/jobs/14bb4617-0f52-474d-b240-f10c8cfab768"], "isController": false}, {"data": [0.0, 500, 1500, " /api/login/?next=/api/docs"], "isController": false}, {"data": [0.0, 500, 1500, "/api/login/?next=/api/docs"], "isController": true}, {"data": [0.5, 500, 1500, "d7639850-2324-4c8a-9b87-b07658f6378a COMPLETED 825"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 1815, 0, 0.0, 710.3619834710757, 0, 4057, 1000.2000000000003, 1224.3999999999996, 2195.2, 1.4657771324230708, 16.970864108427936, 0.6928300166424255], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Throughput", "Received", "Sent"], "items": [{"data": [" /api/jobs/6a852af1-30be-49f0-81c8-1360feb54bd8", 1, 0, 0.0, 694.0, 694, 694, 694.0, 694.0, 694.0, 1.440922190201729, 2.909987391930836, 0.5924103926512969], "isController": false}, {"data": ["/api/runs?job_uid=c3e67e02-124f-4954-8420-31353a891bb5", 167, 0, 0.0, 676.6586826347306, 429, 1623, 925.8000000000003, 1120.7999999999997, 1621.6399999999999, 0.15036361884713423, 1.6857391151258596, 0.06886771214775972], "isController": false}, {"data": ["28fc074b-6a9b-4370-8a59-6432df9ea729 COMPLETED 830", 1, 0, 0.0, 524.0, 524, 524, 524.0, 524.0, 524.0, 1.9083969465648853, 26.456643606870227, 0.8740607108778625], "isController": false}, {"data": [" /api/jobs/f813acbb-2a01-4f5d-be7b-2acdd89e630c", 1, 0, 0.0, 773.0, 773, 773, 773.0, 773.0, 773.0, 1.29366106080207, 2.6087989165588614, 0.5318665103492884], "isController": false}, {"data": [" /api/jobs", 40, 0, 0.0, 836.325, 153, 2472, 2053.8, 2267.95, 2472.0, 0.0324941977548134, 0.319905218233063, 0.037515884077761866], "isController": false}, {"data": ["c3e67e02-124f-4954-8420-31353a891bb5 COMPLETED 830", 1, 0, 0.0, 571.0, 571, 571, 571.0, 571.0, 571.0, 1.7513134851138354, 24.268689798598952, 0.8021152583187391], "isController": false}, {"data": [" /api/jobs/0162c22c-07b9-4700-8f66-c342d913ec13", 1, 0, 0.0, 832.0, 832, 832, 832.0, 832.0, 832.0, 1.201923076923077, 2.4261474609375, 0.4941500150240385], "isController": false}, {"data": [" /api/jobs/28fc074b-6a9b-4370-8a59-6432df9ea729", 1, 0, 0.0, 1287.0, 1287, 1287, 1287.0, 1287.0, 1287.0, 0.777000777000777, 1.5684185606060608, 0.3194505147630148], "isController": false}, {"data": ["90b87dc5-ae70-4dde-9f73-7a1933a554a8 COMPLETED 825", 1, 0, 0.0, 690.0, 690, 690, 690.0, 690.0, 690.0, 1.4492753623188406, 20.091711956521742, 0.6637794384057971], "isController": false}, {"data": [" /api/jobs/90b87dc5-ae70-4dde-9f73-7a1933a554a8", 1, 0, 0.0, 1197.0, 1197, 1197, 1197.0, 1197.0, 1197.0, 0.835421888053467, 1.686344768170426, 0.343469350459482], "isController": false}, {"data": ["6a852af1-30be-49f0-81c8-1360feb54bd8 COMPLETED 830", 1, 0, 0.0, 567.0, 567, 567, 567.0, 567.0, 567.0, 1.763668430335097, 24.429563492063494, 0.8077739197530865], "isController": false}, {"data": [" /api/jobs/c3e67e02-124f-4954-8420-31353a891bb5", 1, 0, 0.0, 795.0, 795, 795, 795.0, 795.0, 795.0, 1.2578616352201257, 2.5378341194968552, 0.5171481918238994], "isController": false}, {"data": ["/api/runs?job_uid=e419fb87-02e7-4a81-800d-de4e99bd6b6e", 165, 0, 0.0, 710.3878787878782, 457, 1738, 1074.8000000000002, 1299.7999999999997, 1691.8000000000002, 0.14961616652551363, 1.791805016754744, 0.06852537314498623], "isController": false}, {"data": [" /api/jobs/5ab16381-a8c5-44da-b080-1bcba21b0876", 1, 0, 0.0, 691.0, 691, 691, 691.0, 691.0, 691.0, 1.447178002894356, 2.9197946816208398, 0.5949823625180898], "isController": false}, {"data": ["/api/runs?job_uid=d7639850-2324-4c8a-9b87-b07658f6378a", 166, 0, 0.0, 708.5963855421688, 472, 1635, 1046.7, 1310.45, 1608.2000000000005, 0.14965970448519314, 1.7902050780281522, 0.06854531387065976], "isController": false}, {"data": ["/api/runs?job_uid=6a852af1-30be-49f0-81c8-1360feb54bd8", 167, 0, 0.0, 696.3233532934132, 433, 2212, 977.4000000000001, 1187.8, 1834.5999999999963, 0.14992046136002096, 1.6784002782618024, 0.06866474255649398], "isController": false}, {"data": ["5ab16381-a8c5-44da-b080-1bcba21b0876 COMPLETED 905", 1, 0, 0.0, 385.0, 385, 385, 385.0, 385.0, 385.0, 2.5974025974025974, 35.96793831168831, 1.1896306818181819], "isController": false}, {"data": ["/api/runs?job_uid=28fc074b-6a9b-4370-8a59-6432df9ea729", 167, 0, 0.0, 690.047904191617, 424, 2088, 1011.4000000000002, 1207.4, 1771.1199999999967, 0.15007404851255948, 1.6744426310496914, 0.06873508667225624], "isController": false}, {"data": ["Transaction Controller", 10, 0, 0.0, 1135077.1, 1104784, 1226034, 1225039.2, 1226034.0, 1226034.0, 0.008152464123043511, 15.909629272808353, 0.6328947379818411], "isController": true}, {"data": ["0162c22c-07b9-4700-8f66-c342d913ec13 COMPLETED 825", 1, 0, 0.0, 505.0, 505, 505, 505.0, 505.0, 505.0, 1.9801980198019802, 27.440439356435643, 0.9069461633663366], "isController": false}, {"data": [" /api/formats/gpkg", 20, 0, 0.0, 188.29999999999998, 153, 274, 268.60000000000014, 274.0, 274.0, 0.1645169781521453, 0.35202456135660704, 0.11904988360423796], "isController": false}, {"data": ["f813acbb-2a01-4f5d-be7b-2acdd89e630c COMPLETED 915", 1, 0, 0.0, 393.0, 393, 393, 393.0, 393.0, 393.0, 2.544529262086514, 35.25067589058524, 1.1654142811704835], "isController": false}, {"data": ["/api/runs?job_uid=f813acbb-2a01-4f5d-be7b-2acdd89e630c", 184, 0, 0.0, 653.8532608695657, 415, 1607, 972.5, 1082.25, 1538.1500000000005, 0.1508206611190893, 1.607015372590558, 0.0690770410789579], "isController": false}, {"data": ["e419fb87-02e7-4a81-800d-de4e99bd6b6e COMPLETED 820", 1, 0, 0.0, 403.0, 403, 403, 403.0, 403.0, 403.0, 2.4813895781637716, 34.38081575682382, 1.1364958126550868], "isController": false}, {"data": [" /api/docs", 10, 0, 0.0, 2372.2999999999997, 1147, 3402, 3370.1000000000004, 3402.0, 3402.0, 2.110595187842972, 84.62785919691852, 0.5832992560151963], "isController": false}, {"data": [" /api/login/", 20, 0, 0.0, 923.1, 812, 1107, 1102.4, 1107.0, 1107.0, 17.196904557179707, 104.17898215821153, 2.351139294926913], "isController": false}, {"data": ["/api/runs?job_uid=0162c22c-07b9-4700-8f66-c342d913ec13", 166, 0, 0.0, 692.2590361445785, 446, 1573, 925.8000000000002, 1028.0, 1510.6900000000012, 0.1500128324230145, 1.7651518185215243, 0.06870704922499395], "isController": false}, {"data": ["14bb4617-0f52-474d-b240-f10c8cfab768 COMPLETED 820", 1, 0, 0.0, 551.0, 551, 551, 551.0, 551.0, 551.0, 1.8148820326678765, 25.17085412885662, 0.8312301497277677], "isController": false}, {"data": ["/api/runs?job_uid=5ab16381-a8c5-44da-b080-1bcba21b0876", 182, 0, 0.0, 672.0934065934061, 423, 1693, 962.0, 1183.1999999999998, 1612.4899999999989, 0.1504077537676316, 1.6421366637804078, 0.06888792628615158], "isController": false}, {"data": ["/api/runs?job_uid=90b87dc5-ae70-4dde-9f73-7a1933a554a8", 166, 0, 0.0, 686.7168674698797, 459, 1533, 881.5, 1027.3500000000001, 1522.9500000000003, 0.150142273371092, 1.7908191744910993, 0.06876633419047086], "isController": false}, {"data": [" /api/jobs/d7639850-2324-4c8a-9b87-b07658f6378a", 1, 0, 0.0, 974.0, 974, 974, 974.0, 974.0, 974.0, 1.026694045174538, 2.0724380775154003, 0.42210761036960986], "isController": false}, {"data": [" /api/jobs/e419fb87-02e7-4a81-800d-de4e99bd6b6e", 1, 0, 0.0, 970.0, 970, 970, 970.0, 970.0, 970.0, 1.0309278350515465, 2.080984213917526, 0.42384826030927836], "isController": false}, {"data": ["/api/runs?job_uid=14bb4617-0f52-474d-b240-f10c8cfab768", 165, 0, 0.0, 684.9818181818184, 469, 1765, 884.0000000000001, 1021.5, 1364.3800000000022, 0.15018773466833543, 1.881827604107407, 0.06878715581977472], "isController": false}, {"data": ["Debug Sampler", 10, 0, 0.0, 0.39999999999999997, 0, 2, 1.9000000000000004, 2.0, 2.0, 0.0822699936652105, 0.14050172355636728, 0.0], "isController": false}, {"data": [" /api/formats", 30, 0, 0.0, 610.8333333333333, 157, 2026, 1514.4000000000003, 1881.8999999999999, 2026.0, 0.024337315188512787, 0.06855565005982923, 0.014886007564848805], "isController": false}, {"data": [" /api/jobs/14bb4617-0f52-474d-b240-f10c8cfab768", 1, 0, 0.0, 899.0, 899, 899, 899.0, 899.0, 899.0, 1.1123470522803114, 2.24533335650723, 0.45732237208008897], "isController": false}, {"data": [" /api/login/?next=/api/docs", 10, 0, 0.0, 3006.4999999999995, 1830, 4057, 4023.2000000000003, 4057.0, 4057.0, 2.366863905325444, 97.31832470414201, 2.8642751479289945], "isController": false}, {"data": ["/api/login/?next=/api/docs", 10, 0, 0.0, 127257.5, 123678, 132852, 132676.8, 132852.0, 132852.0, 0.07510608734837958, 156.84435026193248, 6.265175243625371], "isController": true}, {"data": ["d7639850-2324-4c8a-9b87-b07658f6378a COMPLETED 825", 1, 0, 0.0, 611.0, 611, 611, 611.0, 611.0, 611.0, 1.6366612111292964, 22.655930339607202, 0.7496036211129297], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 1815, 0, null, null, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
